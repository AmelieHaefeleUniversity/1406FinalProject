package com.company;

public class follower extends NPC{
    public follower(String playStyle,String name, int health, int actionPoints) {
        super(playStyle,name,health,actionPoints);
    }

}
