package com.company;

import static org.junit.Assert.*;

public class fightTest {

    @org.junit.Test
    // make different characters in a character test call and then make a test fightTest class
    public void playFight() {
    }

    @org.junit.Test
    //Insert certain charters alive or dead to check
    public void checkDead() {
    }

    @org.junit.Test
    //this should work but you should at least write 1 test
    public void addLists() {
    }
}